<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="/views/css/bootstrap.min.css">
	<title>Products news</title>
	<style>
		form {
			width: 500px;
			margin: 20px auto;
		}
		h1 {
			text-align: center;
		}
	</style>
</head>
<body>
	<div id="">